export class Alert {

    type: string;
    msg: string;
    timeout: number;
    dismissible:boolean;

}