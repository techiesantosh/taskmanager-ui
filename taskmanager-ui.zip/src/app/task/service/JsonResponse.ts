export interface JsonResponse {

    code?: string;
    message?: string;
    result: any;

}

