export class TaskForm {
  taskName: string;
  priority: number;
  parentTask: string;
  startDate: string;
  endDate: string;
  parentTaskId: number;
}
