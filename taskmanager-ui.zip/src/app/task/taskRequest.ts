export class TaskRequest {
    public username: string;
    public taskName: string;
    public priority: number;
    public parentTask: string;
    public taskId: number;
    public parentTaskId: number;
    public startDate: string;
    public endDate: string;

}
