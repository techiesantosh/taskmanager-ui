export interface JsonResponse {

   
    message?: string;
    result: any;
   
}
