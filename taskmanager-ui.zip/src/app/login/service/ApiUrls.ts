 export enum ApiUrls {
    login = '/login',
    userRegister = '/users/register',
    updateTask = '/taskmanager/updatetask/{taskId}',
    deleteTask = '/taskmanager/deletetasks/{taskId}',
    createTask = '/taskmanager/createtask',
    getTasks = '/taskmanager/gettasks/{username}'

}